package com.java.serviceImpl;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.java.model.User;
import com.java.model.UserDto;
import com.java.repo.UserRepository;
import com.java.service.UserService;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;


@Service(value = "userService")
public class UserServiceImpl implements UserDetailsService, UserService {
	
	@Autowired
	private UserRepository userRepo;

	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;

	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		User user = userRepo.findByEmail(email);
		if(user == null){
			throw new UsernameNotFoundException("Invalid username or password.");
		}
		return new org.springframework.security.core.userdetails.User(user.getEmail(), user.getPassword(), getAuthority());
	}

	private List<SimpleGrantedAuthority> getAuthority() {
		return Arrays.asList(new SimpleGrantedAuthority("ROLE_ADMIN"));
	}

	public List<User> findAll() {
		List<User> list = new ArrayList<>();
		userRepo.findAll().iterator().forEachRemaining(list::add);
		return list;
	}

	@Override
	public void delete(long id) {
		userRepo.deleteById(id);
	}

	@Override
	public User findOne(String email) {
		return userRepo.findByEmail(email);
	}
	
	

	@Override
	public User findById(long id) {
		Optional<User> optionalUser = userRepo.findById(id);
		return optionalUser.isPresent() ? optionalUser.get() : null;
	}

    @Override
    public UserDto update(UserDto userDto) {
        User user = findById(userDto.getUser_id());
        if(user != null) {
            BeanUtils.copyProperties(userDto, user, "password");
            userRepo.save(user);
        }
        return userDto;
    }

    @Override
    public User save(UserDto user) {
    	   System.out.println("\n\n\n eNTERING sAVE \n\n\n");
	    User newUser = new User();
	    newUser.setActive(user.isActive());
	    newUser.setEmail(user.getEmail());
	    newUser.setFirst_name(user.getFirst_name());
	    newUser.setLast_name(user.getLast_name());
	    newUser.setPassword(bcryptEncoder.encode(user.getPassword()));
	    newUser.setContact_no(user.getContact_no());
	    newUser.setUserType(user.getUserType());
	    System.out.println("\n\n\n\n successfully values setted \n\n\n\n\n");
        return userRepo.save(newUser);
    }
}
