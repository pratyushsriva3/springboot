package com.java.controller;

import java.util.ArrayList;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.java.model.MentorSkills;
import com.java.repo.MentorSkillsRepository;



@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api")

public class MentorSkillController {
	@Autowired
	private MentorSkillsRepository repository;
	
	@GetMapping("/skills/getAllskill")
	public List<MentorSkills> getAllSkills()
	{
			
			List<MentorSkills> skills = (List<MentorSkills>) repository.findAll();
			
			return skills;
	}
	
}
