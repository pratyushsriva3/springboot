
export class User{
    
     user_id:number;
     email: string;
     password: string;
    first_name: string;
    last_name: string;
    contact_no: string;
    userType:  string;
    active:boolean;
}