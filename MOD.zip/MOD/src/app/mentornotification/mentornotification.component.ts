import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentornotification',
  templateUrl: './mentornotification.component.html',
  styleUrls: ['./mentornotification.component.css']
})
export class MentornotificationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
