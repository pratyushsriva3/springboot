import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentorpayment',
  templateUrl: './mentorpayment.component.html',
  styleUrls: ['./mentorpayment.component.css']
})
export class MentorpaymentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
