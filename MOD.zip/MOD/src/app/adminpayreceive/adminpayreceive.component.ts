import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminpayreceive',
  templateUrl: './adminpayreceive.component.html',
  styleUrls: ['./adminpayreceive.component.css']
})
export class AdminpayreceiveComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
