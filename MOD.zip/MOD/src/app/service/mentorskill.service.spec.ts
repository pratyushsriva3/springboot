import { TestBed } from '@angular/core/testing';

import { MentorskillService } from './mentorskill.service';

describe('MentorskillService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MentorskillService = TestBed.get(MentorskillService);
    expect(service).toBeTruthy();
  });
});
